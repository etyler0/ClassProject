/*****************************************************
 * Class Project
 *
 * Class: CS1C at 10am, T/TH
 * Group: ERKK (Eugene, Richard, Kevin, Kole)
 * Created on: 4/4/18
 *****************************************************/

#ifndef RECTANGLE_H
#define RECTANGLE_H

/*****************************************************
 * Pre-processor directives
 *****************************************************/
// Standard directives
#include <iostream>
#include <math.h>
using namespace std;

// Qt libraries/directives that will be utilized
#include <QWidget> // This gives access to the QWidget base class, the base of all UI objects
#include <QPen>    // This gives access to the QPen class, which defines how a QPainter should draw lines and outline of shapes
#include <QBrush>  // This gives access to the QBrush class, which defines the fill pattern of shapes drawn by QPainter
#include <QFont>   // This gives access to the QFont class, which specifies a font used for drawing text
#include <QPainter>// This gives access to the QPainter class, which preforms the painting on widgets and other paint devices
#include <QPoint>  // This gives access to the QPoint class, which defines points on a plane

// Custom libraries/directives
// Custom 


 /*************************************************************************************************************
  * Rectangle Base Class (Inherits from Shape.h)
  *
  * Basic 2D drawing example link - http://doc.qt.io/qt-5/qtwidgets-painting-basicdrawing-example.html
  *************************************************************************************************************/


class Rectangle : public Shape
{
public:
    // Default constructor
    Rectangle(QPaintDevice* device,
              int xId = -1,
              shape sRec = shape::Rectangle,
              QPen xPen = Qt::NoPen,
              QBrush xBrush = Qt::NoBrush,
              QPoint xUL = QPoint(0,0),
              int xWidth = 0,int xHeight = 0):
              Shape(device, xId, sRec, xPen, xBrush), upperLeft(xUL), width(xWidth), height(xHeight){}

    // draw() function from shape base class
    void draw(QPaintDevice* device)
    {
        QPainter& rPaint = getPainter();
        rPaint.begin(device);
        rPaint.setPen(this->getPen());
        rPaint.setBrush(this->getBrush());
        rPaint.drawRect((getUpperLeft()).x(),(getUpperLeft()).y(),getWidth(),getHeight());
        rPaint.setPen(QPen());
        rPaint.drawText(getUpperLeft().x()-5,getUpperLeft().y()-5,QString::number(this->getId()));
        rPaint.end();
    }

    void move(Shape* source)
    {
        this->setUpperLeft(source->getUpperLeft());
        this->setWidth(source->getWidth());
        this->setHeight(source->getHeight());
    }

    double calcPerimeter()
    {
        return ((getWidth()*2)+(getHeight()*2));
    }

    double calcArea()
    {
        return (getWidth()*getHeight());
    }

    void setUpperLeft(QPoint xRecUL)
    {
        upperLeft = xRecUL;
    }

    void setWidth(int recW)
    {
        width = recW;
    }

    void setHeight(int recH)
    {
        height = recH;
    }

    QPoint getUpperLeft()
    {
        return upperLeft;
    }

    int getWidth()
    {
        return width;
    }

    int getHeight()
    {
        return height;
    }

private:
    QPoint upperLeft;

    int width;
    int height;



};

#endif // RECTANGLE_H
