var searchData=
[
  ['begin',['begin',['../classnserkkvector_1_1MyVector.html#acbc69c4ebe8b558f2501288defc408f3',1,'nserkkvector::MyVector::begin()'],['../classnserkkvector_1_1MyVector.html#a75db7328d5f9b832ddefc5b150400b31',1,'nserkkvector::MyVector::begin() const ']]],
  ['brush',['brush',['../classShape2D.html#ad2a39e54a4cce0f95547225ad6282f54',1,'Shape2D']]]
];
