var searchData=
[
  ['pen',['pen',['../classShape1D.html#add0a527e431b0d5a216b600a2c60903a',1,'Shape1D::pen()'],['../classShape2D.html#a703b6a05045fdfdd01a362fe80c6db73',1,'Shape2D::pen()']]],
  ['points',['points',['../classPolygon.html#a2b9f4ab753cc0a4e8e844fac8c3d05a2',1,'Polygon::points()'],['../classShape1D.html#a5cafd442acdfe031e4fd9db08a119e23',1,'Shape1D::points()']]]
];
