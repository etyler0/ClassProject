var searchData=
[
  ['lowerright',['lowerright',['../classShape1D.html#a5783a298129c1797b89c38fba3ab1888',1,'Shape1D::lowerright()'],['../classShape2D.html#ac09b295b11d1668f6c696ac8480e9466',1,'Shape2D::lowerright()'],['../classText.html#a0f21d563e534b5faf41ba11f5ae9316c',1,'Text::lowerright()']]]
];
