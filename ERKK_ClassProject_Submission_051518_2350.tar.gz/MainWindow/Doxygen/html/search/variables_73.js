var searchData=
[
  ['string',['String',['../classText.html#aedb55d46b763e08f05098533acfbe22a',1,'Text']]]
];
