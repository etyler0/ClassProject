var searchData=
[
  ['rectangle',['Rectangle',['../classRectangle.html',1,'Rectangle'],['../classRectangle.html#a6e0872acf1be9c941846e9b2548e04af',1,'Rectangle::Rectangle()']]],
  ['renderarea',['renderArea',['../classrenderArea.html',1,'']]],
  ['reports',['reports',['../classreports.html',1,'reports'],['../classreports.html#af072c228ae3065ef7566630d3f6b131c',1,'reports::reports()']]],
  ['reserve',['reserve',['../classnserkkvector_1_1MyVector.html#adcd5abe3736336323650ac82177a735b',1,'nserkkvector::MyVector']]],
  ['resize',['resize',['../classnserkkvector_1_1MyVector.html#a1ba1aa4622327c812e5fe82babdae347',1,'nserkkvector::MyVector']]]
];
