var searchData=
[
  ['get_5fqpaintdevice',['get_qPaintDevice',['../classShape.html#a7c3eb344a269d95e48ecd102cd46938e',1,'Shape']]],
  ['get_5fqpainter',['get_qPainter',['../classShape.html#a517f7b1e67d2a3aeac8a093a873d5674',1,'Shape']]],
  ['getaccess',['getAccess',['../classprivilege.html#a3924d6b685150666db220ea6c4f3b895',1,'privilege']]],
  ['getid',['getId',['../classShape.html#a8783318515d368f9ba7b8f73a343e59b',1,'Shape']]],
  ['getshapetype',['getShapeType',['../classShape.html#a76eade96838eac557423a4ca8c0d9aef',1,'Shape']]]
];
