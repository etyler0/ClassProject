var searchData=
[
  ['brush',['brush',['../classShape2D.html#ad2a39e54a4cce0f95547225ad6282f54',1,'Shape2D']]]
];
