CS1C - Team ERKK
Revisied 05/10/18

Submission List
1) README.txt - this file
			
2) QT source tree is in MainWindow directory
3) C++ files written by team are in MainWindow and also in erkk-Codefiles
      Note: Not currently populated
4) Text file pointing out where required C++ features are implemented (this file)
Use of required C++ features:
Inheritance: Shape->Shape-2D-><circle.h/polygon.h/rectangle.h/square.h>
Composition: Polygon.h: line 26 contains a vector<QPoint>
Exception Handler: vector.h line 132, throws an exception for an invalid
                   number of elements to preallocate
Virtual Functions: shape.h lines 60-68 base class provides 8 functions that
                   can or must (pure virtual) be overloaded by derived
		   classes 
Overloaded Operators: shape.h lines 69, 88  overlaod of << for debug printing
                        and () for comparisons

5) SCRUM artifacts - not yet attached
6) Doxygen output - not yet attached
7) UML - not yet attached
8) 
9)
10) Valgrind output - VectorUNitTest directory - see .txt file
11) Team member contribution form - CS1C_ERKK_TEAM.pdf in 
    MiscSubmissions-README directory 

Note - extra credit for selection sort in selection_sort.h/cpp
			
      


