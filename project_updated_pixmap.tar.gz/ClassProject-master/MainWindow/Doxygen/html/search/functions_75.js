var searchData=
[
  ['update',['update',['../classCircle.html#ae9c239fb51beadf9d6be4861473949f5',1,'Circle::update()'],['../classEllipse.html#a49d149cb6210f1b2fb58b10fbd8bed18',1,'Ellipse::update()'],['../classLine.html#a2338aa100616356ad580303478c102c2',1,'Line::update()'],['../classPolygon.html#a723d9ffbebe8964da953dcd52aafeec2',1,'Polygon::update()'],['../classPolyLine.html#a4d48598e631ad4e94a232e026f458555',1,'PolyLine::update()'],['../classRectangle.html#a1679d95f9c3f0794a9fc54ca26509b6f',1,'Rectangle::update()'],['../classSquare.html#acfd8a9b71e6cf950c34eb022cbe3ae11',1,'Square::update()'],['../classText.html#a04fa355437faa0911800bbf110bf8f0e',1,'Text::update()']]],
  ['updatetestimonies',['updateTestimonies',['../classtestimonials.html#af04e654a01033ca548d34aff2d84a948',1,'testimonials']]]
];
