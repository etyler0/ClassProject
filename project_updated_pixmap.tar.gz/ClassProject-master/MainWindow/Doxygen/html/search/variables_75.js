var searchData=
[
  ['upperleft',['upperleft',['../classShape1D.html#a2a00297b7ebd6dcd64beb0474e6cd42d',1,'Shape1D::upperleft()'],['../classShape2D.html#a04ff6cd950715ef89ecea1d4004e2cab',1,'Shape2D::upperleft()'],['../classText.html#a32e176ed2a90d7267df882653a135d97',1,'Text::upperleft()']]]
];
