var searchData=
[
  ['fontfamily',['FontFamily',['../classText.html#a41605f83ceba0843f91b4cbbb62c16e2',1,'Text']]],
  ['fontsize',['FontSize',['../classText.html#ada5a7bd7fd75b0c00b6343603690b40b',1,'Text']]]
];
