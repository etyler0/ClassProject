var searchData=
[
  ['polygon',['Polygon',['../classPolygon.html',1,'']]],
  ['polyline',['PolyLine',['../classPolyLine.html',1,'']]],
  ['privilege',['privilege',['../classprivilege.html',1,'']]]
];
