var searchData=
[
  ['alignment',['Alignment',['../classText.html#ac2f10e06ac4a483c431f7a0f5e589e0c',1,'Text']]]
];
