var searchData=
[
  ['color',['Color',['../classText.html#a7080675fdb6da03a3d9fc141c3f9ee48',1,'Text']]]
];
