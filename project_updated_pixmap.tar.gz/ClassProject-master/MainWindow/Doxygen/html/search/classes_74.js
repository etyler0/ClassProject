var searchData=
[
  ['testimonials',['testimonials',['../classtestimonials.html',1,'']]],
  ['text',['Text',['../classText.html',1,'']]]
];
