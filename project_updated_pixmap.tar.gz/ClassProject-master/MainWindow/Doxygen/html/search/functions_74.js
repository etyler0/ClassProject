var searchData=
[
  ['testimonials',['testimonials',['../classtestimonials.html#aeda8ceffc4fc863bade365d69f75e9f2',1,'testimonials']]],
  ['text',['Text',['../classText.html#a33b6e89d37f8d0db9abaa02a82a5d7ed',1,'Text']]]
];
